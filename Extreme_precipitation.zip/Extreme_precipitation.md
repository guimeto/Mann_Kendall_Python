## Compute extreme precipitation indices 

![extreme-rain.jpg](attachment:extreme-rain.jpg)

###  Evaluation of extreme indices

In order to provide some insight into changes in extreme climate events (e.g., dry or wet spells or
cold/warm spells, etc.), a set of descriptive indices of extremes could be developed.

These indices are helpful for monitoring climate change itself and can be used as benchmarks for evaluating
climate change scenarios (see the STARDEX project, 2004; Gachon et al., 2005). The indices
describe particular characteristics of extremes, including frequency, amplitude/intensity and
persistence/duration. 

In the present post, a set of eight frequency and intensity precipitation indices will be computed (see table bellow).

<p>&nbsp;</p>
<p style='margin:0cm;font-size:15px;font-family:"Arial",sans-serif;margin-top:0cm;margin-right:14.65pt;margin-bottom:.1pt;margin-left:20.85pt;text-align:justify;line-height:150%;'><strong><span style="font-size:13px;line-height:150%;">Table</span></strong><strong><span style="font-size:13px;line-height:150%;">.&nbsp;</span></strong><span style="font-size:13px;line-height:150%;">A set of indices of extreme weather based on daily values of temperature and precipitation (STARDEX 2004:&nbsp;</span><a href="https://crudata.uea.ac.uk/projects/stardex/">https://crudata.uea.ac.uk/projects/stardex/</a>&nbsp;<span style="font-size:13px;line-height:150%;">; Gachon <em>et al.</em>, 2005, Frich <em>et al.</em>, 2002).</span></p>
<table style="width: 4.8e+2pt;margin-left:20.5pt;border-collapse:collapse;border:none;">
    <tbody>
        <tr>
            <td style="width: 71.9pt;border: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 40.45pt;vertical-align: top;">
                <p style='margin-top:.05pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:13px;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:4.2pt;font-size:15px;font-family:"Arial",sans-serif;'><strong><span style="font-size:13px;color:black;">Measure</span></strong></p>
            </td>
            <td style="width: 63.8pt;border-top: 1pt solid black;border-right: 1pt solid black;border-bottom: 1pt solid black;border-image: initial;border-left: none;background: rgb(243, 243, 243);padding: 0cm;height: 40.45pt;vertical-align: top;">
                <p style='margin-top:.05pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:13px;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:14.2pt;font-size:15px;font-family:"Arial",sans-serif;'><strong><span style="font-size:13px;color:black;">Indices</span></strong></p>
            </td>
            <td style="width: 262.25pt;border-top: 1pt solid black;border-right: 1pt solid black;border-bottom: 1pt solid black;border-image: initial;border-left: none;background: rgb(243, 243, 243);padding: 0cm;height: 40.45pt;vertical-align: top;">
                <p style='margin-top:.05pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:13px;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:2.95pt;margin-bottom:.0001pt;margin-left:2.9pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'><strong><span style="font-size:13px;color:black;">Description [unit]</span></strong></p>
            </td>
            <td style="width: 85.1pt;border-top: 1pt solid black;border-right: 1pt solid black;border-bottom: 1pt solid black;border-image: initial;border-left: none;background: rgb(243, 243, 243);padding: 0cm;height: 40.45pt;vertical-align: top;">
                <p style='margin-top:2.9pt;margin-right:12.45pt;margin-bottom:.0001pt;margin-left:13.4pt;font-size:15px;font-family:"Arial",sans-serif;text-indent:1.4pt;line-height:150%;'><strong><span style="font-size:13px;line-height:150%;color:black;">Time Scale</span></strong></p>
            </td>
        </tr>
        <tr>
            <td style="width: 71.9pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0cm;height: 23.2pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:4.9pt;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:13px;">Frequency</span></p>
            </td>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 23.2pt;vertical-align: top;">
                <p style='margin-top:2.9pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:18.35pt;font-size:15px;font-family:"Arial",sans-serif;'><em><span style="font-size:13px;color:black;">Prcp1</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 23.2pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  2.95pt;margin-bottom:.0001pt;margin-left:2.9pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Number of wet days (precipitation &ge; 1 mm) [%]</span></p>
            </td>
            <td rowspan="6" style="width: 85.1pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 23.2pt;vertical-align: top;">
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'>&nbsp;</p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'>&nbsp;</p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'>&nbsp;</p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'>&nbsp;</p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:5.6pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Monthly</span></p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:5.6pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">-</span></p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:5.6pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Seasonal</span></p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:5.6pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">-</span></p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:5.6pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Annual</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 71.9pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0cm;height: 23.25pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:9.95pt;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:13px;">Intensity</span></p>
            </td>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 23.25pt;vertical-align: top;">
                <p style='margin-top:2.9pt;margin-right:  20.45pt;margin-bottom:.0001pt;margin-left:20.4pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'><em><span style="font-size:13px;color:black;">SDII</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 23.25pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  2.95pt;margin-bottom:.0001pt;margin-left:2.9pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Precipitation intensity [mm/day]</span></p>
            </td>
        </tr>
        <tr>
            <td rowspan="6" style="width: 71.9pt;border-right: 1pt solid black;border-bottom: 1pt solid black;border-left: 1pt solid black;border-image: initial;border-top: none;padding: 0cm;height: 43.5pt;vertical-align: top;">
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'>&nbsp;</p>
                <p style='margin-top:.25pt;margin-right:0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:17px;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:6.4pt;margin-bottom:.0001pt;margin-left:7.4pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-.05pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:6.4pt;margin-bottom:.0001pt;margin-left:7.4pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-.05pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:6.4pt;margin-bottom:.0001pt;margin-left:7.4pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-.05pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">&nbsp;</span></p>
                <p style='margin-top:0cm;margin-right:6.4pt;margin-bottom:.0001pt;margin-left:7.4pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-.05pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">Duration and Extremes</span></p>
            </td>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 43.5pt;vertical-align: top;">
                <p style='margin-top:.4pt;margin-right:  0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'>&nbsp;</p>
                <p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:20.55pt;font-size:15px;font-family:"Arial",sans-serif;'><em><span style="font-size:13px;color:black;">CDD</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 43.5pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  2.95pt;margin-bottom:.0001pt;margin-left:2.8pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Number of consecutive dry days</span></p>
                <p style='margin-top:8.75pt;margin-right:  2.95pt;margin-bottom:.0001pt;margin-left:2.9pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">(precipitation &lt; 1 mm) [day]</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 43.5pt;vertical-align: top;">
                <p style='margin-top:.4pt;margin-right:  0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'>&nbsp;</p>
                <p style='margin-top:.4pt;margin-right:  0cm;margin-bottom:.0001pt;margin-left:0cm;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'><em><span style="font-size:13px;color:black;">CWD</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 43.5pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  2.95pt;margin-bottom:.0001pt;margin-left:2.8pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Number of consecutive wet days</span></p>
                <p style='margin-top:2.85pt;margin-right:  2.95pt;margin-bottom:.0001pt;margin-left:2.8pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">(precipitation &lt; 1 mm) [day]</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 23.15pt;vertical-align: top;">
                <p style='margin-top:2.9pt;margin-right:  20.45pt;margin-bottom:.0001pt;margin-left:20.45pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;'><em><span style="font-size:13px;color:black;">R3d</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 23.15pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  2.9pt;margin-bottom:.0001pt;margin-left:2.9pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><span style="font-size:13px;">Greatest 3-day precipitation [mm]</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin-top:11.55pt;margin-right:  0cm;margin-bottom:.0001pt;margin-left:8.5pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><em><span style="font-size:13px;color:black;">Prec90pc<strong><sup>1</sup></strong></span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  19.5pt;margin-bottom:.0001pt;margin-left:53.55pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-33.35pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">90<sup>th</sup> percentile of precipitation (extreme precipitations) [mm/day]</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin-top:11.55pt;margin-right:  0cm;margin-bottom:.0001pt;margin-left:8.5pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><em><span style="font-size:13px;color:black;">PrecTOT</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  19.5pt;margin-bottom:.0001pt;margin-left:53.55pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-33.35pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">Total cumulated precipitation [mm]</span></p>
            </td>
            <td style="width: 85.1pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin:0cm;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:1px;">&nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 63.8pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;background: rgb(243, 243, 243);padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin-top:11.55pt;margin-right:  0cm;margin-bottom:.0001pt;margin-left:8.5pt;font-size:15px;font-family:"Arial",sans-serif;text-align:  center;'><em><span style="font-size:13px;color:black;">MOY</span></em></p>
            </td>
            <td style="width: 262.25pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin-top:2.85pt;margin-right:  19.5pt;margin-bottom:.0001pt;margin-left:53.55pt;font-size:15px;font-family:"Arial",sans-serif;text-align:center;text-indent:-33.35pt;line-height:150%;'><span style="font-size:13px;line-height:150%;">Mean precipitation [mm]</span></p>
            </td>
            <td style="width: 85.1pt;border-top: none;border-left: none;border-bottom: 1pt solid black;border-right: 1pt solid black;padding: 0cm;height: 40.5pt;vertical-align: top;">
                <p style='margin:0cm;font-size:15px;font-family:"Arial",sans-serif;'><span style="font-size:1px;">&nbsp;</span></p>
            </td>
        </tr>
    </tbody>
</table>



- The mean precipitation intensity is defined simply by the amount of total precipitation falling in a wet day (using the threshold ≥ 1 mm/day to define a wet day). 

- The maximum number of consecutive dry days is used to characterize the length of dry spells. 

- The maximum number of consecutive wet days is used to characterize the length of wet spells. 

- The greatest three days total rainfall describes extremes in precipitation amount. 

- For a very wet day, the 90th percentile value is obtained from all non-zero total precipitation events (i.e. ≥ 1 mm/day). 


###  Datasets used    

We will compute these extreme precipitation indices using daily precipitation data from the second generation homogenized dataset of Environment and Climate Change Canada developed by Vincent et al. 2012.


We will first load and clean precipitation timeseries folowing this post:  https://www.guillaumedueymes.com/post/eccc_temp/

   
## 1-  Let's import Python librairies   


```python
import pandas as pd
import os
from datetime import date
import calendar
import numpy as np
from dateutil.relativedelta import relativedelta
import warnings
warnings.filterwarnings("ignore")
```

We will first work with one station from this document:


```python
dataframe = pd.read_excel("./Adj_Precipitation_Stations.xls", skiprows = range(0, 3))
```


```python
station = dataframe.iloc[0]
station
```




    Prov                      BC
    nom de la station    AGASSIZ
    stnid                1100120
    année déb.              1890
    mois déb.                  1
    année fin.              2017
    mois fin.                 12
    lat (deg)            49.2431
    long (deg)           -121.76
    élév (m)                  15
    stns jointes              No
    Name: 0, dtype: object



##  2 - Loading source file

Let's load time serie ofr AGASSIZ's station and clean the data. We will load daily precipitation from 1981 to 2017:


```python
stnid = '1100120'   
path = 'F:/DATA/Donnees_Stations/2nd_generation_V2019/Adj_Daily_Total_v2017'
varin = 'dt'  
f1 = open(path+'/'+str(varin)+str(stnid)+'.txt', 'r')
f2 = open('./tmp.txt', 'w')
for line in f1:
    for word in line:
            if word == 'M':
                f2.write(word.replace('M', ' '))
            elif word == 'a':
                f2.write(word.replace('a', ' '))                    
            else:
                f2.write(word)
f1.close()
f2.close()      
df_station = pd.read_csv('./tmp.txt', delim_whitespace=True, skiprows = range(0, 4))
df_station.columns = ['Year', 'Month', 'D1','D2','D3','D4','D5','D6','D7','D8','D9','D10',
                                  'D11','D12','D13','D14','D15','D16','D17','D18','D19','D20',
                                  'D21','D22','D23','D24','D25','D26','D27','D28','D29','D30','D31']
     
os.remove("./tmp.txt")
   
   # nettoyage des valeurs manquantes 
try:  
    df_station = df_station.replace({'E':''}, regex=True)
except:
       pass
try: 
    df_station = df_station.replace({'a':''}, regex=True)
except:
       pass
try:     
    df_station = df_station.replace({'-9999.9':''}, regex=True)
except:
       pass
try:     
    df_station = df_station.replace({-9999.9:''}, regex=True)
except:
       pass    
    
for col in  df_station.columns[2:]:
       df_station[col] = pd.to_numeric(df_station[col], errors='coerce')  
```

<table border="1" class="dataframe" style='box-sizing: border-box; border-collapse: collapse; border-spacing: 0px; background-color: rgb(255, 255, 255); margin-left: 0px; margin-right: 0px; border: none; color: rgb(0, 0, 0); font-size: 12px; table-layout: fixed; margin-top: 1em; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;'>
    <thead style="box-sizing: border-box; border-bottom: 1px solid black; vertical-align: bottom;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Year</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Month</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D1</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D2</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D3</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D4</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D5</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D6</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D7</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D8</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">...</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D22</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D23</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D24</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D25</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D26</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D27</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D28</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D29</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D30</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">D31</th>
        </tr>
    </thead>
    <tbody style="box-sizing: border-box;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">0</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1890</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">5</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7.91</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">20.08</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.87</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">5.21</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1890</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">29.23</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">28.19</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2.09</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.83</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">13.95</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1890</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.83</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.13</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">17.69</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.78</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">5.52</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.56</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">3</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1890</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">8</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.69</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.83</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.34</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">21.33</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">4</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1890</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">17.38</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.74</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.57</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">...</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1527</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2017</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">8</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.95</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1528</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2017</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7.48</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.15</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">8.90</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.05</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgba(66, 165, 245, 0.2);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1529</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2017</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.36</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.74</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">19.31</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7.88</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2.58</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.56</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.13</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.95</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1530</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2017</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">11</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.31</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.76</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">32.77</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">12.78</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2.17</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.86</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">27.06</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.80</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">14.82</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.25</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.25</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1531</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">2017</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">12</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">18.70</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.74</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.19</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">Na</td>
        </tr>
    </tbody>
</table>

We will clean this dataset in order to only have daly values timeserie:


```python
yearmin = 1980                               
yearmax = 2017                                   
m_start =  df_station['Month'].loc[(df_station['Year'] == yearmin)].min()
m_end   =  df_station['Month'].loc[(df_station['Year'] == yearmax)].max()
d_end = calendar.monthrange(yearmax, m_end)[1]                     

tmp_pr = [ ] 
for year in range(yearmin,yearmax+1):    ### Loop over years
    for month in range(1,13):
        df = []
        last_day = calendar.monthrange(year, month)[1] 
        tmin = df_station.loc[(df_station["Year"] == year) & (df_station["Month"] == month)].iloc[:,2:last_day+2].values
           
        if len(tmin) == 0:
            a = np.empty((calendar.monthrange(year,month)[1]))
            a[:] = np.nan
            df=pd.DataFrame(a)
        else:
            df=pd.DataFrame(tmin.T)
               
        start = date(year, month, 1)
        end =   date(year, month, last_day)
        delta=(end-start) 
        nb_days = delta.days + 1 
        rng = pd.date_range(start, periods=nb_days, freq='D')          
        df['datetime'] = rng
        df.index = df['datetime']
        tmp_pr.append(df)
           
tmp_pr = pd.concat(tmp_pr) 
preacc = pd.DataFrame({'datetime': tmp_pr['datetime'], 'Pr': tmp_pr.iloc[:,0]}, columns = ['datetime','Pr']) 
preacc.index = preacc['datetime']
preacc = preacc.drop(["datetime"], axis=1)
```

<table border="1" class="dataframe" style='box-sizing: border-box; border-collapse: collapse; border-spacing: 0px; background-color: rgb(255, 255, 255); margin-left: 0px; margin-right: 0px; border: none; color: rgb(0, 0, 0); font-size: 12px; table-layout: fixed; margin-top: 1em; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;'>
    <thead style="box-sizing: border-box; border-bottom: 1px solid black; vertical-align: bottom;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">datetime</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Pr</th>
        </tr>
    </thead>
    <tbody style="box-sizing: border-box;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-01-01</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-01-02</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-01-03</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-01-04</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-01-05</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">...</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-12-27</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-12-28</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-12-29</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-12-30</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.0</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-12-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.</td>
        </tr>
    </tbody>
</table>

Quick plot: 


```python
import matplotlib.pylab as plt
import datetime
plt.rcParams["figure.figsize"]=[10,6]        
plt.plot(preacc.index, preacc[:],  label='Preciputation Station', linewidth=2, c='r')
plt.title('Daily precipitation: from ' + datetime.date(yearmin, 1, 1).strftime('%Y')+ ' et '  + datetime.date(yearmax, 1, 1).strftime('%Y'), fontsize=15, color='black', weight='semibold')
plt.xlabel('Time', fontsize=15, color='black', weight='semibold')
plt.ylabel('mm', fontsize=15, color='black', weight='semibold')
plt.show()
```


    
![png](output_13_0.png)
    


##  3 - Compute monthly extreme precipitation indices 

We will compute  extreme precipitation indices presented in previous table.



```python
# Total cumulated precipitation
def PrecTOT(S):
     import numpy as np
     ind_PrecTOT=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if ((N2/N) < 0.8):
         ind_PrecTOT = np.empty(1)
         ind_PrecTOT = np.nan
     else:     
         ind_PrecTOT = np.nansum(S_no_nan)        
     return ind_PrecTOT 
 
# Mean precipitation value of input signal 
def MOY(S):
     import numpy as np
     ind_moy=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if ((N2/N) < 0.8): 
         ind_moy = np.empty(1)
         ind_moy = np.nan
     else:    
         ind_moy = np.nanmean(S_no_nan)  
     return ind_moy      


# No of wet days (precipitation ≥ 1 mm) [%]
def Prcp1(S):
     import numpy as np
     ind_Prcp1=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if (N2 == 0):
         N2=1
         
     if ((N2/N) < 0.8): 
         ind_Prcp1 = np.empty(1)
         ind_Prcp1 = np.nan
     else:
         ind_Prcp1 = 0
         for row in S_no_nan:
             if row >= 1 :
                 ind_Prcp1 += 1 
                 
         ind_Prcp1 = 100 * (ind_Prcp1/N2)
     return ind_Prcp1        
 
# Calculates the 90th percentile of precipitation (mm/day).
def Prec90p(S):
     import numpy as np
     ind_Prec90p=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
# condition on available data >= 80%
     if ((N2/N) < 0.8): 
         ind_Prec90p = np.empty(1)
         ind_Prec90p = np.nan
     else:
         SS = S[S > 1]
# For Prec90p, we need more than 15 values
         if len(SS)  < 15 :
             ind_Prec90p = np.empty(1)
             ind_Prec90p = np.nan  
         else :        
             s_sorted = np.sort(SS)
# the rank "m" is calculated from the semi-empirical probability formula of Cunnane (1978)
             m=(len(SS)+0.2)*0.9 +0.4
# if rank "m" is not an integer, we have to perform a lineare interpolation           
             if np.remainder(m,1) != 0:
                 m_floor=np.floor(m)
                 m_ceil=np.ceil(m)
                 slope=(s_sorted[int(m_ceil)-1]-s_sorted[int(m_floor)-1])/(m_ceil-m_floor)
                 ind_Prec90p=s_sorted[int(m_floor)-1]+slope*(m-m_floor)
             else: 
                 ind_Prec90p=s_sorted[int(m)-1];
     return ind_Prec90p
 
    
# Calculates the simple daily intensity of precipitation of the input signal.
def SDII(S):
     import numpy as np
     ind_SDII=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if ((N2/N) < 0.8): 
         ind_SDII = np.empty(1)
         ind_SDII = np.nan
     else:
         SS = S[S > 1]        
         ind_SDII = np.nanmean(SS)
     return ind_SDII       

# Maximum number of dry consecutive days
def CDD(S):
     import numpy as np
     ind_CDD=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if ((N2/N) < 0.8): 
         ind_CDD = np.empty(1)
         ind_CDD = np.nan
     else:
         temp = 0
         ind_CDD = 0 
         j =0
         while (j < N2):
             while (j < N2 ) and (S_no_nan[j] < 1.0 ):
                 j += 1
                 temp +=1
             if ind_CDD < temp:
                 ind_CDD = temp
             temp = 0
             j += 1 
     return ind_CDD      
 
# Maximum number of wet consecutive days
def CWD(S):
     import numpy as np
     ind_CWD=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if ((N2/N) < 0.8): 
         ind_CWD = np.empty(1)
         ind_CWD = np.nan
     else:
         temp = 0
         ind_CWD = 0 
         j =0
         while (j < N2):
             while (j < N2 ) and (S_no_nan[j] > 1.0 ):
                 j += 1
                 temp +=1
             if ind_CWD < temp:
                 ind_CWD = temp
             temp = 0
             j += 1 
     return ind_CWD      
 
    
# Calculates the maximum total precipitation cumulated in 3 consecutive days (mm).
def R3d(S):
     import numpy as np
     ind_R3d=[]
     S_no_nan = S[~np.isnan(S)]
     N = len(S)
     N2 = len(S_no_nan)
     if ((N2/N) < 0.8): 
         ind_R3d = np.empty(1)
         ind_R3d = np.nan
     else:
         temp = 0
         ind_R3d = 0 
         for i in range(0,N-2):
             if (~np.isnan(S[i])) and  (~np.isnan(S[i+1]))  and  (~np.isnan(S[i+2])):
                 temp = S[i] + S[i+1] + S[i+2]
             if ind_R3d < temp:
                 ind_R3d = temp
     return ind_R3d          
```

We can put all this fonctions in a common module, it will be easier to load an apply functions:


```python
import Indices_Precipitation
```


```python
list_indices = ['PrecTOT','MOY','SDII' ,'Prcp1','CWD','CDD','Prec90p','R3d']   
```


```python
resamp_preacc = []
for ind in list_indices:
    if ind == 'PrecTOT':
        indice = Indices_Precipitation.PrecTOT  
        indice_out = 'PrecTOT'     
    elif ind == 'SDII':
        indice = Indices_Precipitation.SDII
        indice_out = 'SDII'
    elif ind == 'Prcp1':
        indice = Indices_Precipitation.Prcp1
        indice_out = 'Prcp1'
    elif ind == 'CWD':
        indice = Indices_Precipitation.CWD
        indice_out = 'CWD'
    elif ind == 'MOY':
        indice = Indices_Precipitation.MOY
        indice_out = 'MOY'
    elif ind == 'CDD':
        indice = Indices_Precipitation.CDD
        indice_out = 'CDD'   
    elif ind == 'Prec90p':
        indice = Indices_Precipitation.Prec90p
        indice_out = 'Prec90p'
    elif ind == 'R3d':
        indice = Indices_Precipitation.R3d
        indice_out = 'R3d'
        
    resamp_preacc.append(preacc.resample('M').agg([indice]))
```


```python
monthly_indices = pd.concat(resamp_preacc, axis=1)
monthly_indices.columns = monthly_indices.columns.droplevel(0)
```

<table border="1" class="dataframe" style='box-sizing: border-box; border-collapse: collapse; border-spacing: 0px; background-color: rgb(255, 255, 255); margin-left: 0px; margin-right: 0px; border: none; color: rgb(0, 0, 0); font-size: 12px; table-layout: fixed; margin-top: 1em; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;'>
    <thead style="box-sizing: border-box; border-bottom: 1px solid black; vertical-align: bottom;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">PrecTOT</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">MOY</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">SDII</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Prcp1</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">CWD</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">CDD</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Prec90p</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">R3d</th>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">datetime</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;"><br></th>
        </tr>
    </thead>
    <tbody style="box-sizing: border-box;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-01-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">107.75</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.591667</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.738000</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">33.333333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">14.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">45.86</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgba(66, 165, 245, 0.2);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-02-29</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">190.60</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.807143</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">15.753333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">42.857143</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">68.52</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-03-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">183.30</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.110000</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.082222</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">60.000000</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">24.7738</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">55.48</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-04-30</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">129.34</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.311333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.688333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">40.000000</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">5.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">42.69</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1980-05-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">132.19</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.264194</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">8.228125</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">51.612903</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">5.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">4.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">23.0168</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">45.27</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">...</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">...</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-08-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">27.78</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">0.896129</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">8.763333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.677419</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">16.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.00</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-09-30</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">84.08</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.002857</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.332500</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">28.571429</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">3.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">NaN</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">43.24</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-10-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">270.86</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.028667</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">14.077895</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">63.333333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">5.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">45.2936</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">147.88</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-11-30</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">285.88</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.529333</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">12.388261</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">76.666667</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">20.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">6.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">31.0060</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">81.38</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2017-12-31</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">229.43</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7.911379</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">11.471500</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">68.965517</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">16.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">7.0</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">22.0118</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">89.35</td>
        </tr>
    </tbody>
</table>

- We now can make some quick plots:


```python
import matplotlib.pylab as plt
import datetime
plt.rcParams["figure.figsize"]=[10,6]        
plt.plot(monthly_indices.index, monthly_indices['PrecTOT'],  label='Preciputation Station', linewidth=2, c='b')
plt.title('Monthly cumulated precipitation: from ' + datetime.date(yearmin, 1, 1).strftime('%Y')+ ' et '  + datetime.date(yearmax, 1, 1).strftime('%Y'), fontsize=15, color='black', weight='semibold')
plt.xlabel('Time', fontsize=15, color='black', weight='semibold')
plt.ylabel('mm', fontsize=15, color='black', weight='semibold')
plt.show()
```


    
![png](output_23_0.png)
    



```python
import seaborn as sns
import matplotlib.pyplot as plt 
ax = plt.axes()
sns.boxplot(x=monthly_indices.index.month, y="Prcp1", data=monthly_indices, palette="Set1") 
ax.set_title('Number of days with precipitation in AGASSIZ from 1980 to 2017')
ax.set_ylabel('%')

figure = ax.get_figure()    
figure.set_size_inches(12, 8) 
plt.show()
```


    
![png](output_24_0.png)
    


##  4 - Compute saisonal extreme precipitation indices 

In this section, we will compute seasonal total precipitation for each year from 1981 to 2017 using Indices_Precipitation.PrecTOT fonction. 


```python
#################################### Calcul des indices saisonniers  
djf = []
mam = []
son=[]
jja=[]
incr= date(1981, 1, 1)
end = date(2017, 12, 31)
while incr <= end:
    current_year = str(incr.year)
    last_year = str(incr.year-1)
    try:
        dec = preacc[last_year][np.in1d(preacc[last_year].index.month, [12])]
    except:
        rng = pd.date_range(last_year, periods=31, freq='D')
        dec = pd.DataFrame({'datetime': rng, 'variable': [np.nan]*31}, columns = ['datetime','variable']) 
                
    j_f = preacc[current_year][np.in1d(preacc[current_year].index.month, [1,2])]
            
    djf.append(Indices_Precipitation.PrecTOT(dec.append(j_f)))            
    mam.append(Indices_Precipitation.PrecTOT((preacc[current_year][np.in1d(preacc[current_year].index.month, [3,4,5])])))
    jja.append(Indices_Precipitation.PrecTOT((preacc[current_year][np.in1d(preacc[current_year].index.month, [6,4,8])])))
    son.append(Indices_Precipitation.PrecTOT((preacc[current_year][np.in1d(preacc[current_year].index.month, [9,10,11])])))            
    
    incr = incr + relativedelta(years=1)
```


```python
TIME=[]
for y in range(1981,2017+1,1):
    TIME.append(y)
df_season = pd.DataFrame({'Date': TIME,'Indice DJF': djf, 'Indice MAM':mam, 'Indice JJA':jja, 'Indice SON':son}, 
                         columns = ['Date','Indice DJF', 'Indice MAM', 'Indice JJA', 'Indice SON']) 

```


```python
df_season.set_index("Date", inplace = True)
```


```python
df_season[["Indice DJF", "Indice MAM", "Indice JJA", "Indice SON"]].plot(kind="bar", stacked=True)
ax = plt.axes()
ax.set_title("Total precipitation / season: Agassiz")
ax.set_ylabel('mm')
ax.set_xlabel('Time') 
figure = ax.get_figure()    
figure.set_size_inches(12, 8) 
plt.show()
```


    
![png](output_29_0.png)
    


##  5 - Compute annual extreme precipitation indices 

In this last exemple, we will compute the maximum number of wet consecutive days for each year in our Agassiz's daily precipitation time serie.  

We will call Indices_Precipitation.SDII fonction. 


```python
annual = []
df_annual = []
incr= date(1980, 1, 1)
end = date(2017, 12, 31)
while incr <= end:
    current_year = str(incr.year)
    annual.append(Indices_Precipitation.SDII(preacc[current_year].values))         
    incr = incr + relativedelta(years=1)
```


```python
TIME=[]
for y in range(1980,2017+1,1):
    TIME.append(y) 
df_annual = pd.DataFrame({'Date': TIME,'Consecutive Wet Days': annual}, columns = ['Date','Consecutive Wet Days']) 
```

<table border="1" class="dataframe" style='box-sizing: border-box; border-collapse: collapse; border-spacing: 0px; background-color: rgb(255, 255, 255); margin-left: 0px; margin-right: 0px; border: none; color: rgb(0, 0, 0); font-size: 12px; table-layout: fixed; margin-top: 1em; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;'>
    <thead style="box-sizing: border-box; border-bottom: 1px solid black; vertical-align: bottom;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Date</th>
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">Consecutive Wet Days</th>
        </tr>
    </thead>
    <tbody style="box-sizing: border-box;">
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">0</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1980</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">12.304610</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">1</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1981</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">9.504310</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">2</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1982</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.580000</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none;">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">3</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1983</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">10.806190</td>
        </tr>
        <tr style="box-sizing: border-box; text-align: right; vertical-align: middle; padding: 0.5em; line-height: normal; white-space: normal; max-width: none; border: none; background: rgb(245, 245, 245);">
            <th style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none; font-weight: bold;">4</th>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">1984</td>
            <td style="box-sizing: border-box; padding: 0.5em; text-align: right; vertical-align: middle; line-height: normal; white-space: normal; max-width: none; border: none;">11.20237</td>
        </tr>
    </tbody>
</table>


```python
ax = plt.axes()
plt.plot( 'Date', 'Consecutive Wet Days', data=df_annual, marker='o', color='mediumvioletred')
ax.set_title('Annual Maximum of Consecutive Wet Days in AGASSIZ from 1980 to 2017')
ax.set_ylabel('Days')
figure = ax.get_figure()    
figure.set_size_inches(12, 8) 
plt.show()
```


    
![png](output_35_0.png)
    



```python

```
